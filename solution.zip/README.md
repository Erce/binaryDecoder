/**
 * This project contains code for BinaryDecoder. 
 * 
 * 1. Unzip the project files to a folder

 * To run the project:
 * 1. Install dependencies with `npm install`
 * 2. Run the project with `npm start`
 * 
 * To run tests:
 * 1. Install dependencies with `npm install`
 * 2. Run tests with `npm test`
 */