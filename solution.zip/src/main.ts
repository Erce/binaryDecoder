import { BinaryDecoder } from './BinaryDecoder';

const decoder = new BinaryDecoder();
decoder.start();

